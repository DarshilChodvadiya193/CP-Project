import React from 'react';
// import LoginPage from './Components/loginpage'

import Signup from './Components/signup';
function App() {
  return (
    <>
    <Signup/>
    </>      
  );
}

export default App;
