import React from 'react'
import './Signup.css';
function Signup() {
  return (
    <div class="container">
        <section class="form-section">
            <center>
            <div class="form-container">
                <img src="https://cdn.builder.io/api/v1/image/assets/TEMP/0dfb1b992d5d5765858625d91eff78fb9454f589016654d5d1044bbdc1c8459d?apiKey=2958b6fa89ad456f9819776504d8ed26&" alt="Hostel Illustration" class="image"/>
                <div class="heading">Start your hostel journey with a quick login</div>
                <form>
                    <div class="input-group">
                        <input type="text" id="firstName" placeholder="First Name" aria-label="First Name"/>
                        <input type="text" id="lastName" placeholder="Last Name" aria-label="Last Name"/>
                    </div>
                    <div class="input-group">
                        <input type="email" id="email" placeholder="Email" aria-label="Email"/>
                    </div>
                    <div class="input-group">
                        <input type="tel" id="mobileNo" placeholder="Mobile No" aria-label="Mobile No" maxlength="10"/>
                    </div>
                    <div class="input-group">
                        <select id="gender" class="select-input" aria-label="Gender">
                            <option value="">Select Gender</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                            <option value="other">Other</option>
                            
                        </select>
                        
                </div>
                <div class="input-group">
                        <select id="Institute" class="select-input" aria-label="Institute">
                            <option value="">Institute</option>
                            <option value="UVPCE">UVPCE</option>
                            <option value="BSPP">BSPP</option>
                            <option value="DCS">DCS</option>
                            <option value="SKPCER">SKPCER</option>
                            <option value="MUIS">MUIS</option>
                            <option value="CHAS">CHAS</option>
                            <option value="CMSR">CMSR</option>
                        </select>
                        
                </div>
                <div class="input-group">
                    <select id="gender" class="select-input" aria-label="Gender">
                        <option value="">Department</option>
                        <option value="male">Information Technology</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                        
                    </select>
                    
            </div>
            <div class="input-group">
                <select id="gender" class="select-input" aria-label="Gender">
                    <option value="">Sem</option>
                    <option value="one">1</option>
                    <option value="two">2</option>
                    <option value="three">3</option>
                    <option value="four">4</option>
                    <option value="fifth">5</option>
                    <option value="six">6</option>
                    <option value="seven">7</option>
                    <option value="eight">8</option>
                </select>

                
        </div>
        
                    <button type="submit" class="button">Sign Up</button>
                </form>
                <div>Already have an account?</div>
            </div>
        </center>
        </section>
       
        <section class="image-section">
            <img src="./photos/Signup.png" alt="" class="decorative-image"/>
        </section>
        
    </div>
  )
}

export default Signup
