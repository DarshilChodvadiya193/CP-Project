import React from 'react'

import styles from './loginpage.css'

const LoginPage = (props) => {
  return (
    <div className='container'>
      <div className='login-page'>
        <img
          src="./photos/Sign Up.png"
          alt="phot"
          className='alenrojnic-t1-yvmf4ole-qunsplash1'
        />
        <img
          src="/rectangle149-xft-800w.png"
          alt="Rectangle149"
          className='rectangle1'
        />
        <span className='text'>
          <span>Forgot password?</span>
        </span>
        <span className='text02'>
          <span>
            <span>&quot;Start your hostel journey with</span>
            <br></br>
            <span> a quick Login.&quot;</span>
          </span>
        </span>
        <img
          src="/rectangle2412-8it-200h.png"
          alt="Rectangle2412"
          className='rectangle2'
        />
        <img
          src="/rectangle3413-glxx-200h.png"
          alt="Rectangle3413"
          className='rectangle3'
        />
        <img
          src="/rectangle4414-xyuc-200h.png"
          alt="Rectangle4414"
          className='rectangle4'
        />
        <span className='text07'>
          <span>Username</span>
        </span>
        <span className='text09'>
          <span>Password</span>
        </span>
        <span className='text11'>
          <span>Confirm Password</span>
        </span>
        <span className='text13'>
          <span>Don’t have an account ?</span>
        </span>
        <img
          src="/hostelmanagementhighresolutionlogotransparent453-rwj-200h.png"
          alt="hostelmanagementhighresolutionlogotransparent453"
          className='hostelmanagementhighresolutionlogotransparent'
        />
        <img
          src="/rectangle51421-3w7-200h.png"
          alt="Rectangle51421"
          className='rectangle5'
        />
        <b
        utton className='login-button'>
          <span className='text15'>
            <span>Login</span>
          </span>
          <img
            src="/loginicon2917-2f0kp.svg"
            alt="LoginIcon2917"
            className='login-icon'
          />
        </b>
        <img
          src="/usericon428-wlyf.svg"
          alt="UserIcon428"
          className='user-icon'
        />
        <img
          src="/lock1531-i55r-200h.png"
          alt="Lock1531"
          className='lock'
        />
      </div>
    </div>
  )
}

export default LoginPage
